const bool debugMode = true;

void debugLog(String message) {
  if (debugMode) print(message);
}
